package FProg;

//Class that represent item in the board
public class BoardLogic {
    public int cellStatus;
    private int  rowPosition;
    private int  cellState;

    public BoardLogic()
    {
        cellStatus = 0;
        rowPosition  =  0;
        cellState = 0;
    }
}
